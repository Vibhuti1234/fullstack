package com.mindtree.trackerapp.controller.handler;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.mindtree.trackerapp.controller.ExpenseController;
import com.mindtree.trackerapp.exception.ServiceException;
import com.mindtree.trackerapp.model.ErrorDto;

@RestControllerAdvice(assignableTypes= {ExpenseController.class})
public class ControllerExceptionHandler {
	@ExceptionHandler(ServiceException.class)
	public ResponseEntity<ErrorDto> serviceExceptionHandler(Exception e, Throwable cause){
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ErrorDto(e.getMessage(), cause));
	}

}