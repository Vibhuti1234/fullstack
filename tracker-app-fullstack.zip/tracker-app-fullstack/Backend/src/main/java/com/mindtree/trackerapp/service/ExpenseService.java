package com.mindtree.trackerapp.service;

import java.util.List;

import com.mindtree.trackerapp.exception.TrackerAppException;
import com.mindtree.trackerapp.model.Expense;

public interface ExpenseService {
	List<Expense> findAll();

	Expense addExpense(Expense expense);

	Expense getExpenseById(long id) throws TrackerAppException;

	void deleteExpense(long id);
	

}
