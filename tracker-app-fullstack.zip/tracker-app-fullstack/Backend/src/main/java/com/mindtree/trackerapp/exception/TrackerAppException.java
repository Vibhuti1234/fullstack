package com.mindtree.trackerapp.exception;

public class TrackerAppException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public TrackerAppException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TrackerAppException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public TrackerAppException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public TrackerAppException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public TrackerAppException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
