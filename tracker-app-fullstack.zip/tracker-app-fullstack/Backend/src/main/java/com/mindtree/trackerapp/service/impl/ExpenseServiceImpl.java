package com.mindtree.trackerapp.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.trackerapp.exception.NoSuchExpenseFoundException;
import com.mindtree.trackerapp.exception.TrackerAppException;
import com.mindtree.trackerapp.model.Expense;
import com.mindtree.trackerapp.repository.ExpenseRepository;
import com.mindtree.trackerapp.service.ExpenseService;
@Service
public class ExpenseServiceImpl implements ExpenseService{
@Autowired
private ExpenseRepository expenseRepository;
	@Override
	public List<Expense> findAll() {
		// TODO Auto-generated method stub
		return expenseRepository.findAll();
	}
	@Override
	public Expense addExpense(Expense expense) {
		// TODO Auto-generated method stub
		expenseRepository.save(expense);
		return expense;
	}
	@Override
	public Expense getExpenseById(long id) throws TrackerAppException {
		// TODO Auto-generated method stub
		Expense expense=expenseRepository.findAll().stream().filter(i->i.getId()==id).findAny().orElseThrow(()->new NoSuchExpenseFoundException("No such expense found:"));
		return expense;
	}
	@Override
	public void deleteExpense(long id) {
		// TODO Auto-generated method stub
		// we are excluding exception for now
		expenseRepository.deleteById(id);
		
	}

}
