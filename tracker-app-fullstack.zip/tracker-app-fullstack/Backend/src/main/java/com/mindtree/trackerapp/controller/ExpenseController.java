package com.mindtree.trackerapp.controller;

import java.util.List;

import javax.persistence.GeneratedValue;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.trackerapp.exception.TrackerAppException;
import com.mindtree.trackerapp.model.Expense;
import com.mindtree.trackerapp.service.ExpenseService;
@CrossOrigin("*")
@RestController
@RequestMapping("/api/v1")
public class ExpenseController {
	@Autowired
	private ExpenseService expenseService;
	@GetMapping(value="/expenses")
	public ResponseEntity<List<Expense>> get()
	{
		List<Expense> expenses= expenseService.findAll();
		return new ResponseEntity<List<Expense>>(expenses,HttpStatus.OK);
	}
	@PostMapping(value="/addExpenses")
	public ResponseEntity<Expense> addExpenses(@RequestBody Expense expense)
	{
		Expense expense2=expenseService.addExpense(expense);
		return new ResponseEntity<Expense>(expense2,HttpStatus.OK);
	}
	@GetMapping(value="/getExpenseById/{id}")
	public  ResponseEntity<Expense> getExpenseById(@PathVariable long id ) throws TrackerAppException
	{
		Expense expense=expenseService.getExpenseById(id);
		return new ResponseEntity<Expense>(expense,HttpStatus.OK);
	}
	@DeleteMapping(value="/deleteExpense/{id}")
	public ResponseEntity<String> deleteExpense(@PathVariable long id)
	{
		expenseService.deleteExpense(id);
		return new ResponseEntity<String>("Expense deleted success fully",HttpStatus.OK);
	}

}
