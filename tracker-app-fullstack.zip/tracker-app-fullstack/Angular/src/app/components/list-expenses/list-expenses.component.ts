import { Component, OnInit } from '@angular/core';
import { ExpenseService } from 'src/app/services/expense.service';
import { Expense } from 'src/app/models/expense';
import { Router, ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-list-expenses',
  templateUrl: './list-expenses.component.html',
  styleUrls: ['./list-expenses.component.css']
})
export class ListExpensesComponent implements OnInit {
  sw = false;
  filters= {
    keyword:'',
    sortBy:'normal'
  }

  expenses: Expense[] = [];
  expense: Expense;
  constructor(private expenseService: ExpenseService, private router: Router, private route: ActivatedRoute ) { }

  ngOnInit(): void {
    // this.expenseService.getExpenses().subscribe(data => this.expenses = data );
     this.listExpenses();
  }

  onAddExpense() {
    this.router.navigate(['/addExpenses']);

  }
  onEditExpense(id: number) {
     // this.expenseService.getExpense(id).subscribe(data => this.expense = data);
     // u can also use navigateByUrl or router link in order to achieve routing
          this.router.navigate(['/editexpense/' + id]);
  }
  // onDeleteExpense(id: number) {
  //   this.expenseService.deleteExpense(id).subscribe(data => {console.log(data) ; });
  //   this.router.navigate(['/expenses']);
  // }
  listExpenses() {
    this.expenseService.getExpenses().subscribe(data => this.expenses = this.filterExpense(data) );

  }
sortExpense()
{
  this.expenseService.getExpenses().subscribe(data => this.expenses = this.SortedExpense(data) );
 
}
  filterExpense(expenses: Expense[]) {
    console.log(this.filters.keyword);
    return expenses.filter((e)=>{
       return e.expense.toLowerCase().includes(this.filters.keyword.toLowerCase());
    });
  }
  SortedExpense(expenses: Expense[]) {
    console.log(this.filters.keyword);
    return expenses.filter((e)=>{
       return e.expense.toLowerCase().includes(this.filters.keyword.toLowerCase());
    }).sort((a, b)=>{
      if(this.filters.sortBy==='name')
      {
          return a.expense.toLowerCase()<b.expense.toLowerCase()?-1:1;
      } else if(this.filters.sortBy==='amount')
      {
          return a.amount>b.amount?-1:1;  
      }

    });
  }
}
