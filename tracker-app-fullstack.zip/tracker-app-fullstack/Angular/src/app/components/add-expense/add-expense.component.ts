import { Component, OnInit, ViewChild } from '@angular/core';
import { ExpenseService } from 'src/app/services/expense.service';
import { Expense } from 'src/app/models/expense';
import { Router, ActivatedRoute } from '@angular/router';
import { NgForm } from '@angular/forms';


@Component({
  selector: 'app-add-expense',
  templateUrl: './add-expense.component.html',
  styleUrls: ['./add-expense.component.css']
})
export class AddExpenseComponent implements OnInit {
  @ViewChild('f' , { static: false } ) expenseForm: NgForm;
   isDeleteMode = false;
   deleteId: number;
   isEditableMode = false;

  expense: Expense = new Expense();
  constructor(private expenseService: ExpenseService, private router: Router, private route: ActivatedRoute) { }

  ngOnInit(): void {
    // key value pair paramMap
   const isIdPresent = this.route.snapshot.paramMap.has('id');
   if (isIdPresent) {
     this.isEditableMode = true;
     this.isDeleteMode = true;
     const id = + this.route.snapshot.paramMap.get('id');
     this.expenseService.getExpense(id).subscribe(data => { this.expense = data;this.deleteId=data.id;
      // tslint:disable-next-line: align
                                                            this.expenseForm.value.id = data.id;
                                                            this.expenseForm.value.amount = data.amount;
                                                            this.expenseForm.value.description = data.description;
                                                            this.expenseForm.value.expense = data.expense
                                                           // tslint:disable-next-line: align
                                                           this.expenseForm.setValue(
        { id: this.expense.id,
          expense: this.expense.expense,
         description: this.expense.description,
         amount: this.expense.amount
        }
      );
    });
    // this.expenseForm.value.expenseData.expense = this.expense.expense;
     // console.log( this.expenseForm.value.expenseData.expense);
       }
  }
  onSaveExpense() {
     this.expenseService.addExpense(this.expense).subscribe(data => {console.log(data); } );
     this.router.navigate(['expenses'], {relativeTo: this.route});
    // this.router.navigate(['new'], {relativeTo: this.route});


  }
  onSubmit()
  {  this.expense.id = this.expenseForm.value.id;
     this.expense.expense = this.expenseForm.value.expense;
     this.expense.description = this.expenseForm.value.description;
     this.expense.amount = this.expenseForm.value.amount;
     console.log(this.expenseForm);
     // console.log(this.expenseForm);
     this.expenseService.addExpense(this.expense).subscribe(data => {console.log(data); } );
     this.expenseService.getExpenses().subscribe(data => {console.log(data); } );
     this.router.navigate(['/expenses']);
     this.expenseForm.reset();

    // this.expenseForm.resetForm();
  }
  onDelete(id: number)
  {
    this.expenseService.deleteExpense(id).subscribe(response => { console.log(response); } );
    this.expenseService.getExpenses().subscribe(response => {console.log(response); });
    this.router.navigate(['/expenses']);
  }
  // onSubmit(form: NgForm) {
  //   const value = form.value;
  //   const expense = new Expense();
  //  // expense.id = value.id;
  //   expense.expense = value.expense;
  //   expense.description = value.description;
  //   expense.amount = value.amount;
  //   this.expenseService.addExpense(expense).subscribe(data => {console.log(data); } );
  //   this.router.navigate(['/expenses']);
  //   this.expenseForm.reset();
  //   // this.expenseForm.resetForm();
  // }

}
