import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddExpenseComponent } from './components/add-expense/add-expense.component';
import { ListExpensesComponent } from './components/list-expenses/list-expenses.component';


const routes: Routes = [{ path: '', redirectTo: '/expenses', pathMatch: 'full' },
{path: 'addExpenses', component: AddExpenseComponent},
{path: 'expenses', component: ListExpensesComponent},
{path: 'editexpense/:id', component: AddExpenseComponent},
{path: 'home', component: ListExpensesComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
