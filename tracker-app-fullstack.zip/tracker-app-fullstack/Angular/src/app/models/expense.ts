export class Expense {
    id: number;
    expense: string;
    description: string;
    amount: number;
}
