import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Expense } from '../models/expense';
import { map, tap, take, exhaustMap } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class ExpenseService {
  private getUrl = 'http://localhost:8081/api/v1/expenses';
  private postUrl = 'http://localhost:8081/api/v1/addExpenses';
  private getExpenseUrl = 'http://localhost:8081/api/v1/getExpenseById';
  private delUrl='http://localhost:8081/api/v1/deleteExpense';
  constructor(private http: HttpClient) { }
  getExpenses(): Observable<Expense[]> {
    return this.http.get<Expense[]>(this.getUrl).pipe(
      // tslint:disable-next-line: arrow-return-shorthand
      map(response => {return response; })
    );

  }

  addExpense(expense: Expense): Observable<Expense> {
    return this.http.post<Expense>(this.postUrl, expense);
  }
  getExpense(id: number): Observable<Expense> {
    return this.http.get<Expense>(`${this.getExpenseUrl}/${id}`).pipe(map(response => response));
  }
  deleteExpense(id: number): Observable<any>{
    return this.http.delete(`${this.delUrl}/${id}`, {responseType: 'text'});
  }
}
