package com.mindtree.angularfullstackapp.service;

import java.util.List;

import com.mindtree.angularfullstackapp.entity.ApplicationException;
import com.mindtree.angularfullstackapp.entity.Friend;

public interface FriendService {

	List<Friend> getFriends();

	Friend addFriend(Friend friend);

	void deleteFriend(int id);

	Friend updateFriend(int id, Friend friend) throws ApplicationException;

}
