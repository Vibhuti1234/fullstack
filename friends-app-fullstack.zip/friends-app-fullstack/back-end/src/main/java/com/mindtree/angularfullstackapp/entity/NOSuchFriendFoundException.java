package com.mindtree.angularfullstackapp.entity;

public class NOSuchFriendFoundException  extends ServiceException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NOSuchFriendFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public NOSuchFriendFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public NOSuchFriendFoundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public NOSuchFriendFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public NOSuchFriendFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
             
}
