package com.mindtree.angularfullstackapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.angularfullstackapp.entity.ApplicationException;
import com.mindtree.angularfullstackapp.entity.Friend;
import com.mindtree.angularfullstackapp.service.FriendService;
@CrossOrigin("*")
@RestController
public class AngularFullStackController {
	@Autowired
	private FriendService friendService;
	@GetMapping(value="/getFriends")
	public ResponseEntity<List<Friend>> getFriends()
	{
		List<Friend> friends= friendService.getFriends();
		return new ResponseEntity<List<Friend>>(friends,HttpStatus.OK);

	}
	@PostMapping(value="/addFriend")
	public ResponseEntity<Friend> addFriend(@RequestBody Friend friend)
	{
		Friend friend2=friendService.addFriend(friend);
		return new ResponseEntity<Friend>(friend2,HttpStatus.OK);
	}
	@DeleteMapping(value="/deleteFriend/{id}")
	public ResponseEntity<String>  deleteFriend(@PathVariable int id)
	{
		friendService.deleteFriend(id);
		return new ResponseEntity<String>("friend deleted success fully",HttpStatus.OK);
	}
	@PutMapping("/updateFriend/{id}")
	public ResponseEntity<Friend> updateFriend(@PathVariable int id,@RequestBody Friend friend) throws ApplicationException
	{
		Friend friend2=friendService.updateFriend(id,friend);
		return new ResponseEntity<Friend>(friend2,HttpStatus.OK);

	}
}
