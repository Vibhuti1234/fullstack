package com.mindtree.angularfullstackapp.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.angularfullstackapp.entity.ApplicationException;
import com.mindtree.angularfullstackapp.entity.Friend;
import com.mindtree.angularfullstackapp.entity.NOSuchFriendFoundException;
import com.mindtree.angularfullstackapp.repository.FriendRepository;
import com.mindtree.angularfullstackapp.service.FriendService;
@Service
public class FriendServiceImpl implements FriendService {
	@Autowired
   private FriendRepository friendRepository;
	@Override
	public List<Friend> getFriends() {
		// TODO Auto-generated method stub
		return friendRepository.findAll();
	}
	@Override
	public Friend addFriend(Friend friend) {
		// TODO Auto-generated method stub
		friendRepository.save(friend);
		return friend;
	}
	@Override
	public void deleteFriend(int id) {
       friendRepository.deleteById(id);		
	}
	@Override
	public Friend updateFriend(int id, Friend friend) throws ApplicationException {
		// TODO Auto-generated method stub
		Friend friend2=friendRepository.findAll().stream().filter(i->i.getId()==id).findAny().orElseThrow(()->new NOSuchFriendFoundException("No friend Found of such id:"));
		friend.setId(friend2.getId());
		friendRepository.saveAndFlush(friend);
		return friend ;
		
		
	}

}
