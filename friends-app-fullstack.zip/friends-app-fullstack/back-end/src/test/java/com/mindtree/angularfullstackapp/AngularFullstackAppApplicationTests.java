package com.mindtree.angularfullstackapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AngularFullstackAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
