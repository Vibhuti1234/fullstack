export class Friend {
    // tslint:disable-next-line: max-line-length
    constructor(public id: number, public firstname: string, public lastname: string, public department: string, public email: string, public country: string) {}
}
