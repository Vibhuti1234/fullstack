import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Friend } from './friends.model';
import { Observable } from 'rxjs';
import { map, tap, take, exhaustMap } from 'rxjs/operators';
import { NgForm, FormGroup } from '@angular/forms';


@Injectable({providedIn: 'root'})
export class FriendService {
    friends: Friend[];
    editUrl: any;
    deleteUrl: any;
   

    constructor(private http: HttpClient){ }
    getFriends(): Observable<Friend[]> {
       return  this.http.get<Friend[]>('http://localhost:8081/getFriends').pipe( map(response => {
           return response;
       }));
      }
      addFriend(form: NgForm): Observable<Friend> {
          return  this.http.post<Friend>('http://localhost:8081/addFriend', form.value).pipe(map(response => { return response; }));
      }
      updateFriend(form: FormGroup): Observable<Friend> {
          this.editUrl = 'http://localhost:8081/updateFriend/' + form.value.id;
          return this.http.put<Friend>(this.editUrl, form.value).pipe(map(response => {
              return response;
          }));
      }
      // tslint:disable-next-line: ban-types
      deleteFriend(id: number) {
         this.deleteUrl = 'http://localhost:8081/deleteFriend/' + id;
          // tslint:disable-next-line: align
          //     return this.http.delete(`${this.delUrl}/${id}`, {responseType: 'text'}); if you face issue you can  do like that also
         return this.http.delete(this.deleteUrl, {responseType: 'text'});
      }
}
