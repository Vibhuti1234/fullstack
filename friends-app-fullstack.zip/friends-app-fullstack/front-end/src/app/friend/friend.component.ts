import { Component, OnInit } from '@angular/core';
import { Friend } from '../shared/friends.model';
import { FriendService } from '../shared/friend.service';
import {ModalDismissReasons, NgbModal} from '@ng-bootstrap/ng-bootstrap';
import { NgForm, FormGroup, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-friend',
  templateUrl: './friend.component.html',
  styleUrls: ['./friend.component.css']
})
export class FriendComponent implements OnInit {
  deleteId: number;
  editForm: FormGroup;
 friends: Friend[];
 closeResult: string;
  constructor(private friendService: FriendService , private modalService: NgbModal,private formBuilder: FormBuilder
    ) { }

  ngOnInit(): void {
    this.getFriends();
    this.editForm = this.formBuilder.group({
      id: [''],
      firstname: [''],
      lastname: [''],
      department: [''],
      email: [''],
      country: ['']
    } );
  }
  getFriends() {
    // tslint:disable-next-line: arrow-return-shorthand
    this.friendService.getFriends().subscribe(friends => {
      this.friends = friends;
      console.log(this.friends);
      return this.friends; });
  }

  addFriend(content) {
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }
  getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }
  onSubmit(f: NgForm) {
this.friendService.addFriend(f).subscribe((response) => {
  this.ngOnInit();
});
this.modalService.dismissAll(); // dismiss the modal

  }
  openDetails(targetModal, friend: Friend) {
    this.modalService.open(targetModal, {
     centered: true,
     backdrop: 'static',
     size: 'lg'
   });
    document.getElementById('fname').setAttribute('value', friend.firstname);
    document.getElementById('lname').setAttribute('value', friend.lastname);
    document.getElementById('dept').setAttribute('value', friend.department);
    document.getElementById('email2').setAttribute('value', friend.email);
    document.getElementById('cntry').setAttribute('value', friend.country);
 }
 openEdit(targetModal, friend: Friend) {
  this.modalService.open(targetModal, {
    backdrop: 'static',
    size: 'lg'
  });
  this.editForm.patchValue( {
    id: friend.id,
    firstname: friend.firstname,
    lastname: friend.lastname,
    department: friend.department,
    email: friend.email,
    country: friend.country
  });
}
onSave() {

  console.log(this.editForm.value);
  this.friendService.updateFriend(this.editForm).subscribe(response => {
    this.ngOnInit();
    this.modalService.dismissAll();
  });

}
openDelete(targetModal, friend: Friend) {
  this.deleteId = friend.id;
  this.modalService.open(targetModal, {
    backdrop: 'static',
    size: 'lg'
  });
}
onDelete() {
  this.friendService.deleteFriend(this.deleteId).subscribe(response => {
      console.log(response);
      this.ngOnInit();
      this.modalService.dismissAll();
    });
}
}
